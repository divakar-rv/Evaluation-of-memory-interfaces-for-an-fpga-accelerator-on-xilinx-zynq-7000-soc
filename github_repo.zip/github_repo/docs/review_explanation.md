# Slide-wise explanation for faculty review

Short spoken explanation for each slide. Replace figures only with values backed by files in `reports/`.

1. **Title:** We evaluate memory types for an FPGA accelerator on Zynq-7000, using matrix multiplication, and compare BRAM, LUTRAM and external DDR.
2. **Introduction:** The accelerator must store and read input and output data. Memory types differ in hardware cost and access time.
3. **Problem statement:** We study how memory choice affects resources and timing, and how the ARM processor controls an FPGA accelerator.
4. **Proposed system:** A 4 x 4 matrix multiplication. ARM runs the software and controls the accelerator, which does the multiplication and accesses memory.
5. **Architecture:** ARM reaches the accelerator through AXI4-Lite. The accelerator's AXI master reaches DDR through PS port HP0.
6. **Memory implementations:** BRAM uses dedicated blocks, LUTRAM uses lookup tables as memory, DDR is external memory through the PS.
7. **Matrix multiplication:** Inputs A and B give output C. Known inputs let us compute the expected result.
8. **Expected output:** The matrix is 1 4 9 16 / 5 12 21 32 / 9 20 33 48 / 13 28 45 64, with element sum 360 as a checksum.
9. **Tools:** Vitis HLS for the accelerator, Vivado for hardware integration and implementation, Vitis for the ARM software.
10. **Resource comparison:** BRAM 67 LUTs, 35 FFs, 1 RAMB18. LUTRAM 195 LUTs, 67 FFs, 128 LUTs as memory. DDR figures as listed in the README.
11. **Timing and latency:** All WNS values are positive. Latency figures are memory-implementation figures, not full application time.
12. **ARM baseline:** 10,000 multiplications in about 6.0456 ms, about 604.56 ns each, checksum 360, PASS.
13. **FPGA hardware execution:** Execution stopped at the `AP_CTRL` register access, so no valid FPGA time exists and no speedup is claimed.
14. **Conclusion:** We compared three memory implementations on resources, timing and reported latency, and built an ARM baseline. The remaining work is a successful accelerator run.

## Answers to keep ready
| Question | Answer |
|---|---|
| Why is DDR slower? | Accesses go through AXI and the PS memory system. Check against the reports. |
| Is the accelerator faster than ARM? | Not known. No valid accelerator time exists. |
| What does WNS mean? | Worst negative slack. Positive means the timing constraint is met. |
| Is latency the same as execution time? | No. It is a memory figure, not the whole application time. |
